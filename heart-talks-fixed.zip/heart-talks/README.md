# HeartTalks

A supportive, anonymous space to share relationship problems and solutions.

## Run locally
```bash
npm install
npm run dev
```

## Build
```bash
npm run build
```
