import React, { useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Heart,
  Search,
  Moon,
  Sun,
  Filter as FilterIcon,
  MessageSquare,
  ThumbsUp,
  Flag,
  Bookmark,
  Send,
  X,
  PlusCircle,
} from "lucide-react";

// -----------------------------
// Utilities
// -----------------------------
const uid = () => Math.random().toString(36).slice(2) + Date.now().toString(36);

const EMOTIONS = [
  { key: "confused", label: "Confused" },
  { key: "angry", label: "Angry" },
  { key: "sad", label: "Sad" },
  { key: "anxious", label: "Anxious" },
  { key: "hopeful", label: "Hopeful" },
];

const CATEGORIES = [
  { key: "marriage", label: "Husband/Wife" },
  { key: "relationship", label: "GF/BF" },
  { key: "affair", label: "Extra-marital" },
  { key: "breakup", label: "Breakups" },
  { key: "trust", label: "Trust & Jealousy" },
];

const BAD_WORDS = [
  "fuck",
  "fucker",
  "asshole",
  "bitch",
  "bastard",
  "slut",
  "whore",
  "dick",
  "cunt",
  "bullshit",
];

const sanitize = (text) => {
  let t = text;
  BAD_WORDS.forEach((w) => {
    const re = new RegExp(`\\\\b${w}\\\\b`, "gi");
    t = t.replace(re, "•••");
  });
  return t;
};

const saveLS = (key, value) => {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (_) {
    // ignore
  }
};
const loadLS = (key, fallback) => {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    const v = JSON.parse(raw);
    return v ?? fallback;
  } catch {
    return fallback;
  }
};

// Simple dev-only tests (run once in effect)
const runSelfTests = () => {
  const assert = (cond, msg) => {
    if (!cond) throw new Error(msg);
  };
  // sanitize tests
  console.assert(sanitize("this is bullshit") === "this is •••", "sanitize should mask bad words");
  // uid uniqueness (probabilistic)
  const ids = new Set();
  for (let i = 0; i < 200; i++) ids.add(uid());
  console.assert(ids.size === 200, "uid should be unique across 200 samples");
  // emotions/cats integrity
  console.assert(EMOTIONS.length > 0 && CATEGORIES.length > 0, "static data present");
  console.log("✅ HeartTalks self-tests passed");
};

// -----------------------------
// Components
// -----------------------------
function Header({ dark, setDark, openComposer }) {
  return (
    <header className="sticky top-0 z-40 backdrop-blur supports-[backdrop-filter]:bg-white/60 dark:supports-[backdrop-filter]:bg-neutral-900/60 bg-white/80 dark:bg-neutral-900/80 border-b border-neutral-200 dark:border-neutral-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="p-2 rounded-2xl bg-rose-100 dark:bg-rose-900/30">
            <Heart className="w-6 h-6 text-rose-600 dark:text-rose-400" />
          </div>
          <div>
            <h1 className="text-xl font-semibold tracking-tight">HeartTalks</h1>
            <p className="text-xs text-neutral-500 dark:text-neutral-400 -mt-1">
              Where hearts speak & minds heal
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={openComposer}
            className="hidden sm:inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-rose-600 text-white text-sm font-medium shadow hover:shadow-md transition-shadow"
          >
            <PlusCircle className="w-4 h-4" /> Share a Problem
          </button>
          <button
            onClick={() => setDark((d) => !d)}
            aria-label="Toggle theme"
            className="inline-flex items-center justify-center w-10 h-10 rounded-2xl border border-neutral-200 dark:border-neutral-800 hover:bg-neutral-50 dark:hover:bg-neutral-800"
          >
            {dark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </button>
        </div>
      </div>
    </header>
  );
}

function Pill({ active, children, onClick }) {
  return (
    <button
      onClick={onClick}
      className={`px-3 py-1.5 rounded-full text-xs font-medium border transition ${active ? "bg-rose-600 text-white border-rose-600" : "bg-white dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800 hover:bg-neutral-50 dark:hover:bg-neutral-800"}`}
    >
      {children}
    </button>
  );
}

function Composer({ onClose, onSubmit }) {
  const [category, setCategory] = React.useState("relationship");
  const [emotion, setEmotion] = React.useState("confused");
  const [title, setTitle] = React.useState("");
  const [content, setContent] = React.useState("");
  const [anonymous, setAnonymous] = React.useState(true);

  const canPost = title.trim().length >= 8 && content.trim().length >= 20;

  const handleSubmit = () => {
    if (!canPost) return;
    const post = {
      id: uid(),
      title: sanitize(title.trim()),
      content: sanitize(content.trim()),
      category,
      emotion,
      author: anonymous ? "Anonymous" : "Member",
      createdAt: Date.now(),
      upvotes: 0,
      bookmarks: 0,
      comments: [],
      reported: false,
    };
    onSubmit(post);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-black/40"
        onClick={onClose}
        aria-hidden
      />
      <div className="relative w-full max-w-2xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-3xl shadow-xl">
        <div className="flex items-center justify-between p-4 border-b border-neutral-200 dark:border-neutral-800">
          <h2 className="text-lg font-semibold">Share your problem</h2>
          <button
            onClick={onClose}
            className="w-9 h-9 inline-flex items-center justify-center rounded-2xl hover:bg-neutral-100 dark:hover:bg-neutral-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 grid gap-4">
          <div className="grid gap-2">
            <label className="text-sm font-medium">Title</label>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="Write a short, clear headline"
              className="w-full rounded-2xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-950 px-4 py-2.5 outline-none focus:ring-2 focus:ring-rose-500"
            />
          </div>

          <div className="grid gap-2">
            <label className="text-sm font-medium">Details</label>
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="Describe what's going on. What have you tried? What kind of help do you want?"
              rows={5}
              className="w-full rounded-2xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-950 px-4 py-3 outline-none focus:ring-2 focus:ring-rose-500 resize-y"
            />
          </div>

          <div className="grid sm:grid-cols-3 gap-4">
            <div className="grid gap-2">
              <label className="text-sm font-medium">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="rounded-2xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-950 px-4 py-2.5"
              >
                {CATEGORIES.map((c) => (
                  <option key={c.key} value={c.key}>
                    {c.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="grid gap-2">
              <label className="text-sm font-medium">How do you feel?</label>
              <select
                value={emotion}
                onChange={(e) => setEmotion(e.target.value)}
                className="rounded-2xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-950 px-4 py-2.5"
              >
                {EMOTIONS.map((e) => (
                  <option key={e.key} value={e.key}>
                    {e.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="grid gap-2">
              <label className="text-sm font-medium">Post as</label>
              <div className="flex items-center gap-3 p-2 rounded-2xl border border-neutral-200 dark:border-neutral-800">
                <label className="flex items-center gap-2 text-sm">
                  <input
                    type="radio"
                    name="anon"
                    checked={anonymous}
                    onChange={() => setAnonymous(true)}
                  />
                  Anonymous
                </label>
                <label className="flex items-center gap-2 text-sm">
                  <input
                    type="radio"
                    name="anon"
                    checked={!anonymous}
                    onChange={() => setAnonymous(false)}
                  />
                  Member
                </label>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between gap-3">
            <p className="text-xs text-neutral-500">
              Be kind. No hate speech. Profanity is automatically filtered.
            </p>
            <button
              onClick={handleSubmit}
              disabled={!canPost}
              className="inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-rose-600 text-white text-sm font-medium shadow hover:shadow-md disabled:opacity-50"
            >
              <Send className="w-4 h-4" /> Post
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function PostCard({ post, onOpen, onVote, onBookmark, onReport }) {
  const category = CATEGORIES.find((c) => c.key === post.category)?.label;
  const emotion = EMOTIONS.find((e) => e.key === post.emotion)?.label;
  const date = new Date(post.createdAt);

  return (
    <div
      className="rounded-3xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-950 p-4 shadow-sm hover:shadow-md transition"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-center gap-2 text-xs text-neutral-500">
            <span className="px-2 py-0.5 rounded-full bg-neutral-100 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800">
              {category}
            </span>
            <span className="px-2 py-0.5 rounded-full bg-rose-50 dark:bg-rose-900/20 border border-rose-200/60 dark:border-rose-800/50 text-rose-700 dark:text-rose-300">
              {emotion}
            </span>
            <span>•</span>
            <span>{date.toLocaleString()}</span>
          </div>
          <h3 className="mt-2 text-lg font-semibold leading-snug break-words">
            {post.title}
          </h3>
          <p className="mt-1 text-sm text-neutral-600 dark:text-neutral-300 line-clamp-3">
            {post.content}
          </p>
          <div className="mt-3 flex items-center gap-3 text-xs text-neutral-500">
            <button
              onClick={() => onVote(post.id)}
              className="inline-flex items-center gap-1.5 px-2 py-1 rounded-full border border-neutral-200 dark:border-neutral-800 hover:bg-neutral-50 dark:hover:bg-neutral-900"
            >
              <ThumbsUp className="w-4 h-4" /> {post.upvotes}
            </button>
            <button
              onClick={() => onBookmark(post.id)}
              className="inline-flex items-center gap-1.5 px-2 py-1 rounded-full border border-neutral-200 dark:border-neutral-800 hover:bg-neutral-50 dark:hover:bg-neutral-900"
            >
              <Bookmark className="w-4 h-4" /> {post.bookmarks}
            </button>
            <button
              onClick={() => onReport(post.id)}
              className="inline-flex items-center gap-1.5 px-2 py-1 rounded-full border border-neutral-200 dark:border-neutral-800 hover:bg-neutral-50 dark:hover:bg-neutral-900"
            >
              <Flag className="w-4 h-4" /> Report
            </button>
          </div>
        </div>
        <button
          onClick={() => onOpen(post)}
          className="shrink-0 inline-flex items-center gap-2 px-3 py-2 rounded-2xl bg-neutral-100 dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 text-xs font-medium hover:bg-neutral-200/60 dark:hover:bg-neutral-800"
        >
          <MessageSquare className="w-4 h-4" /> Open
        </button>
      </div>
    </div>
  );
}

function ThreadModal({ post, onClose, onAddComment, onVote }) {
  const [message, setMessage] = React.useState("");
  if (!post) return null;

  const addComment = () => {
    const text = message.trim();
    if (!text) return;
    const c = {
      id: uid(),
      body: sanitize(text),
      author: "Helper",
      createdAt: Date.now(),
      upvotes: 0,
    };
    onAddComment(post.id, c);
    setMessage("");
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} aria-hidden />
      <div
        className="relative w-full max-w-3xl bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 rounded-3xl shadow-xl"
      >
        <div className="flex items-center justify-between p-4 border-b border-neutral-200 dark:border-neutral-800">
          <h2 className="text-lg font-semibold">{post.title}</h2>
          <button
            onClick={onClose}
            className="w-9 h-9 inline-flex items-center justify-center rounded-2xl hover:bg-neutral-100 dark:hover:bg-neutral-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-4 grid gap-4">
          <p className="text-neutral-700 dark:text-neutral-200 whitespace-pre-wrap">
            {post.content}
          </p>
          <div className="flex items-center gap-3">
            <button
              onClick={() => onVote(post.id)}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-neutral-200 dark:border-neutral-800 hover:bg-neutral-50 dark:hover:bg-neutral-900 text-sm"
            >
              <ThumbsUp className="w-4 h-4" /> {post.upvotes}
            </button>
          </div>

          <div className="mt-2">
            <h3 className="font-medium mb-2">Advice & Responses</h3>
            <div className="grid gap-3">
              {post.comments.length === 0 && (
                <p className="text-sm text-neutral-500">No responses yet. Be the first to help kindly.</p>
              )}
              {post.comments.map((c) => (
                <div
                  key={c.id}
                  className="rounded-2xl border border-neutral-200 dark:border-neutral-800 p-3"
                >
                  <div className="flex items-center justify-between text-xs text-neutral-500">
                    <span>{c.author}</span>
                    <span>{new Date(c.createdAt).toLocaleString()}</span>
                  </div>
                  <p className="mt-1 text-sm">{c.body}</p>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-2 grid gap-2">
            <label className="text-sm font-medium">Add your advice</label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              rows={3}
              placeholder="Share your perspective with empathy and care."
              className="w-full rounded-2xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-950 px-4 py-3 outline-none focus:ring-2 focus:ring-rose-500"
            />
            <div className="flex items-center justify-end">
              <button
                onClick={addComment}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-rose-600 text-white text-sm font-medium shadow hover:shadow-md"
              >
                <Send className="w-4 h-4" /> Send
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// -----------------------------
// Main App
// -----------------------------
export default function App() {
  const [dark, setDark] = React.useState(() => JSON.parse(localStorage.getItem("ht_dark") || "false"));
  const [query, setQuery] = React.useState("");
  const [category, setCategory] = React.useState("all");
  const [emotion, setEmotion] = React.useState("all");
  const [sort, setSort] = React.useState("new");
  const [posts, setPosts] = React.useState(() => JSON.parse(localStorage.getItem("ht_posts_v1") || "[]"));
  const [showComposer, setShowComposer] = React.useState(false);
  const [thread, setThread] = React.useState(null);

  React.useEffect(() => {
    // run tests once on mount
    try { runSelfTests(); } catch (e) { console.error("❌ Self-tests failed:", e); }
  }, []);

  React.useEffect(() => {
    document.documentElement.classList.toggle("dark", !!dark);
    localStorage.setItem("ht_dark", JSON.stringify(dark));
  }, [dark]);

  React.useEffect(() => localStorage.setItem("ht_posts_v1", JSON.stringify(posts)), [posts]);

  // Keep thread in sync with posts updates
  React.useEffect(() => {
    if (!thread) return;
    const updated = posts.find((p) => p.id === thread.id);
    if (updated && updated !== thread) setThread(updated);
  }, [posts, thread]);

  const openComposer = () => setShowComposer(true);

  const filtered = React.useMemo(() => {
    const q = query.trim().toLowerCase();
    let arr = posts.filter((p) => !p.reported);
    if (category !== "all") arr = arr.filter((p) => p.category === category);
    if (emotion !== "all") arr = arr.filter((p) => p.emotion === emotion);
    if (q) {
      arr = arr.filter(
        (p) =>
          p.title.toLowerCase().includes(q) ||
          p.content.toLowerCase().includes(q)
      );
    }
    if (sort === "new") arr = arr.sort((a, b) => b.createdAt - a.createdAt);
    if (sort === "top") arr = arr.sort((a, b) => b.upvotes - a.upvotes);
    return arr;
  }, [posts, category, emotion, sort, query]);

  const createPost = (post) => {
    setPosts((prev) => [post, ...prev]);
    setShowComposer(false);
    setThread(post);
  };

  const vote = (id) => {
    setPosts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, upvotes: p.upvotes + 1 } : p))
    );
  };

  const bookmark = (id) => {
    setPosts((prev) =>
      prev.map((p) => (p.id === id ? { ...p, bookmarks: p.bookmarks + 1 } : p))
    );
  };

  const report = (id) => {
    if (!confirm("Report this post for review?")) return;
    setPosts((prev) => prev.map((p) => (p.id === id ? { ...p, reported: true } : p)));
  };

  const addComment = (postId, comment) => {
    setPosts((prev) =>
      prev.map((p) => (p.id === postId ? { ...p, comments: [...p.comments, comment] } : p))
    );
  };

  // Seed demo content once for first-time users
  React.useEffect(() => {
    if (posts.length === 0) {
      const demo = [
        {
          id: uid(),
          title: "Feeling ignored by my partner lately",
          content:
            "We've both been busy and I feel like our conversations are just logistics now. I miss the emotional connection. How do I bring this up without sounding needy?",
          category: "relationship",
          emotion: "sad",
          author: "Anonymous",
          createdAt: Date.now() - 1000 * 60 * 60 * 5,
          upvotes: 3,
          bookmarks: 1,
          comments: [
            {
              id: uid(),
              body:
                "Try a gentle start-up: 'I miss us. Can we plan 30 mins each night to just talk without phones?'",
              author: "Helper",
              createdAt: Date.now() - 1000 * 60 * 60 * 4,
              upvotes: 0,
            },
          ],
          reported: false,
        },
        {
          id: uid(),
          title: "Caught feelings outside marriage, confused",
          content:
            "I love my spouse but developed feelings for a colleague. Nothing physical yet. I want to do the right thing but my head is a mess. How do I create boundaries?",
          category: "affair",
          emotion: "confused",
          author: "Anonymous",
          createdAt: Date.now() - 1000 * 60 * 60 * 30,
          upvotes: 8,
          bookmarks: 2,
          comments: [],
          reported: false,
        },
      ];
      setPosts(demo);
    }
  }, []);

  return (
    <div className="min-h-screen bg-neutral-50 dark:bg-neutral-950 text-neutral-900 dark:text-neutral-100">
      <Header dark={dark} setDark={setDark} openComposer={openComposer} />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Left: Controls & Composer trigger */}
        <section className="lg:col-span-3 space-y-4">
          {/* Search & Filters */}
          <div className="rounded-3xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-950 p-4">
            <div className="grid md:grid-cols-2 gap-3">
              <div className="flex items-center gap-2 px-3 py-2 rounded-2xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-950">
                <Search className="w-5 h-5" />
                <input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Search problems, keywords…"
                  className="w-full bg-transparent outline-none"
                />
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <button className={`px-3 py-1.5 rounded-full text-xs font-medium border transition ${category==="all"?"bg-rose-600 text-white border-rose-600":"bg-white dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800 hover:bg-neutral-50 dark:hover:bg-neutral-800"}`} onClick={()=>setCategory("all")}>All</button>
                {CATEGORIES.map((c) => (
                  <button key={c.key} className={`px-3 py-1.5 rounded-full text-xs font-medium border transition ${category===c.key?"bg-rose-600 text-white border-rose-600":"bg-white dark:bg-neutral-900 border-neutral-200 dark:border-neutral-800 hover:bg-neutral-50 dark:hover:bg-neutral-800"}`} onClick={()=>setCategory(c.key)}>{c.label}</button>
                ))}
                <div className="ml-auto flex items-center gap-2">
                  <FilterIcon className="w-4 h-4" />
                  <select
                    value={emotion}
                    onChange={(e) => setEmotion(e.target.value)}
                    className="rounded-xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-950 px-2 py-1 text-sm"
                  >
                    <option value="all">All emotions</option>
                    {EMOTIONS.map((e) => (
                      <option key={e.key} value={e.key}>
                        {e.label}
                      </option>
                    ))}
                  </select>
                  <select
                    value={sort}
                    onChange={(e) => setSort(e.target.value)}
                    className="rounded-xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-950 px-2 py-1 text-sm"
                  >
                    <option value="new">Newest</option>
                    <option value="top">Top</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="mt-3 flex sm:hidden">
              <button
                onClick={openComposer}
                className="inline-flex items-center gap-2 px-4 py-2 rounded-2xl bg-rose-600 text-white text-sm font-medium shadow hover:shadow-md"
              >
                <PlusCircle className="w-4 h-4" /> Share a Problem
              </button>
            </div>
          </div>

          {/* Posts feed */}
          <div className="grid gap-4">
            {filtered.length === 0 ? (
              <div className="text-center py-16 rounded-3xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-950">
                <p className="text-neutral-600 dark:text-neutral-300">
                  No posts match your filters yet.
                </p>
              </div>
            ) : (
              filtered.map((p) => (
                <PostCard
                  key={p.id}
                  post={p}
                  onOpen={setThread}
                  onVote={vote}
                  onBookmark={(id)=>{}}
                  onReport={report}
                />
              ))
            )}
          </div>
        </section>

        {/* Right: Sidebar */}
        <div className="space-y-4">
          <section className="rounded-3xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-950 p-4">
            <h3 className="font-semibold">Categories</h3>
            <ul className="mt-2 grid gap-1 text-sm">
              {CATEGORIES.map((c) => (
                <li key={c.key} className="flex items-center justify-between">
                  <span>{c.label}</span>
                  <span className="text-xs text-neutral-500">#</span>
                </li>
              ))}
            </ul>
          </section>
        </div>
      </main>

      <footer className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 text-center text-sm text-neutral-500">
        <p>
          Built with empathy. This is a community space, not professional therapy.
          If you're in immediate danger, contact local emergency services.
        </p>
      </footer>

      {/* Modals */}
      {showComposer && (
        <Composer onClose={() => setShowComposer(false)} onSubmit={createPost} />
      )}
      {thread && (
        <ThreadModal
          post={thread}
          onClose={() => setThread(null)}
          onAddComment={addComment}
          onVote={vote}
        />
      )}
    </div>
  );
}
